//f29 6 23


import com.formdev.flatlaf.FlatIntelliJLaf;
import compilerTools.CodeBlock;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import compilerTools.Directory;
import compilerTools.ErrorLSSL;
import compilerTools.Functions;
import compilerTools.Grammar;
import compilerTools.Production;
import compilerTools.TextColor;
import compilerTools.Token;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author majo
 */
public class Compilador extends javax.swing.JFrame {

    private String title;
    private Directory directorio;
    private ArrayList<Token> tokens;
    private ArrayList<ErrorLSSL> errors;                //ERRORS COULD BE LEXICAL SYNTACTIC SEMANTIC LOGICAL
    private ArrayList<TextColor> textsColor;            //to change text color
    private Timer timerKeyReleased;                     //to paint words in our code editor
    private ArrayList<Production> identProd;            //to get identifiers from syntactic analysys
    private HashMap<String, String> identificadores;    //to save identifiers 
    private boolean codeHasBeenCompiled = false;        //to know if our compiler has been compiled  

    //CONSTRUCTOR
    public Compilador() {
        initComponents();
        init();
    }

//add execute ?    
    private void executeCode(ArrayList<String> blocksOfCode, int repeats) {

        for (int j = 1; j <= repeats; j++) {
            int repeatCode = -1;                //INDICA CUANDO SE REPITE UN CODIGO, -1 indica que no se repite ninguna vez
            for (int i = 0; i < blocksOfCode.size(); i++) {         //para recorrer bloques de codigo
                String blockOfCode;
                blockOfCode = blocksOfCode.get(i);
                if (repeatCode != -1) {         //obtener posiciones de ambos marcadores INICIO FIN con getPositionOfBothMarkers
                    int[] posicionMarcador = CodeBlock.getPositionOfBothMarkers(blocksOfCode, blockOfCode);

                    //RECORTANDO EL ARRAYLIST DEPENDIENDO DE LAS POSICIONES DE AMBOS MARCADORES
                    executeCode(new ArrayList<>(blocksOfCode.subList(posicionMarcador[0], posicionMarcador[1])), repeatCode);
                    repeatCode = -1;                //SALTO A LA POSICION FINAL 
                    i = posicionMarcador[1];        //MARCADORES INICIO FIN YA EJECUTADOS, CON i SE RECORRE LA POSICION DEL ARRAYLIST

                    //SPLIT EN BASE AL ; PARA TENER LAS DECLARACIONES 
                } else {
                    String[] sentences = blockOfCode.split(";");

                    //para recorrer cada una de las sentencias
                    for (String sentence : sentences) {
                        //System.out.println(sentence);

                        //EJECUTAREMOS POR CADA SENTENCIAs
                        sentence = sentence.trim();
                        if (sentence.startsWith("numero")) {
                            String parametro;
                            if (sentence.contains("@")) {       //lo que distingue a un identificador $, obtener el valor del hashmap del identificador
                                parametro = identificadores.get(sentence.substring(7, sentence.length() - 2));  //9 -> 7

                            } else {
                                parametro = sentence.substring(7, sentence.length() - 2);   // 9 -> 7
                            }
                            System.out.println("ESTABLECIENDO NUMERO " + parametro + "...");

                        } else if (sentence.startsWith("leer")) {
                            System.out.println("LEYENDO...");
                            
                        } else if (sentence.startsWith("escribir")) { 
                            System.out.println("25");
                            
                        } else if (sentence.startsWith("asignar")) {
                            System.out.println("ASIGNANDO...");
                            
                            
                            } else if (sentence.startsWith("return")) {
                            System.out.println("25");
                            
                            
                            
                            
                        } else if (sentence.startsWith("=")) {
                            System.out.println("DECLARANDO IDENTIFICADOR...");
                            
                        } else if (sentence.startsWith("while")) {
                            String parametro;
                            if (sentence.contains("$")) {
                                parametro = identificadores.get(sentence.substring(8, sentence.length() - 2));      //8 -> 9
                            } else {
                                parametro = sentence.substring(8, sentence.length() - 2);               //8 -> 9
                            }
                            repeatCode = Integer.parseInt(parametro);           //veces de repeticion sera un numero
                        }

                    }
                }
            }
        }
    }

    private void init() {
        //title = "COMPILADOR ENTREGA FINAL";
        setLocationRelativeTo(null);                    //to move our window in the middle
        setTitle(title);
        directorio = new Directory(this, jtpCode, title, ".txt");
        addWindowListener(new WindowAdapter() {             // click on X in the window

            @Override
            public void windowClosing(WindowEvent e) {
                directorio.Exit();              //do you want to close the window or save?
                System.exit(0);           //close the window
            }

        });
        //Functions.setLineNumberOnJTextComponent(jtpCode);                           //show the line number
        timerKeyReleased = new Timer((int) (1000 * 0.3), (ActionEvent e) -> {
            timerKeyReleased.stop();
            colorAnalysis();
        });
        Functions.insertAsteriskInName(this, jtpCode, () -> {
            timerKeyReleased.restart();
        });
        tokens = new ArrayList<>();
        errors = new ArrayList<>();
        textsColor = new ArrayList<>();
        identProd = new ArrayList<>();
        identificadores = new HashMap<>();
        /*Functions.setAutocompleterJTextComponent(new String[]{}, jtpCode, () -> {     //auto complete when we write code
            timerKeyReleased.restart();
        });*/
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rootPanel = new javax.swing.JPanel();
        buttonsFilePanel = new javax.swing.JPanel();
        btnAbrir = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnGuardarC = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtpCode = new javax.swing.JTextPane();
        panelButtonCompilerExecute = new javax.swing.JPanel();
        btnCompilar = new javax.swing.JButton();
        btnEjecutar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaOutputConsole = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblTokens = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        btnAbrir.setText("Abrir");
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnGuardarC.setText("Guardar como");
        btnGuardarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout buttonsFilePanelLayout = new javax.swing.GroupLayout(buttonsFilePanel);
        buttonsFilePanel.setLayout(buttonsFilePanelLayout);
        buttonsFilePanelLayout.setHorizontalGroup(
            buttonsFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonsFilePanelLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(btnAbrir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGuardarC)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        buttonsFilePanelLayout.setVerticalGroup(
            buttonsFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonsFilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(buttonsFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAbrir)
                    .addComponent(btnGuardar)
                    .addComponent(btnGuardarC))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jtpCode);

        btnCompilar.setText("Compilar");
        btnCompilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompilarActionPerformed(evt);
            }
        });

        btnEjecutar.setText("Ejecutar");
        btnEjecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEjecutarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelButtonCompilerExecuteLayout = new javax.swing.GroupLayout(panelButtonCompilerExecute);
        panelButtonCompilerExecute.setLayout(panelButtonCompilerExecuteLayout);
        panelButtonCompilerExecuteLayout.setHorizontalGroup(
            panelButtonCompilerExecuteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelButtonCompilerExecuteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCompilar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEjecutar)
                .addContainerGap())
        );
        panelButtonCompilerExecuteLayout.setVerticalGroup(
            panelButtonCompilerExecuteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelButtonCompilerExecuteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelButtonCompilerExecuteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCompilar)
                    .addComponent(btnEjecutar))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jtaOutputConsole.setEditable(false);
        jtaOutputConsole.setBackground(new java.awt.Color(255, 255, 255));
        jtaOutputConsole.setColumns(20);
        jtaOutputConsole.setRows(5);
        jScrollPane2.setViewportView(jtaOutputConsole);

        tblTokens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "", "", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTokens.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(tblTokens);
        if (tblTokens.getColumnModel().getColumnCount() > 0) {
            tblTokens.getColumnModel().getColumn(0).setPreferredWidth(300);
        }

        jLabel3.setText("INTRODUCIR ANALISIS");

        jLabel2.setText("ANALISIS LEXICO");

        jLabel1.setText("ANALIZADOR SINTACTICO");

        javax.swing.GroupLayout rootPanelLayout = new javax.swing.GroupLayout(rootPanel);
        rootPanel.setLayout(rootPanelLayout);
        rootPanelLayout.setHorizontalGroup(
            rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rootPanelLayout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rootPanelLayout.createSequentialGroup()
                        .addComponent(buttonsFilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addComponent(panelButtonCompilerExecute, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rootPanelLayout.createSequentialGroup()
                        .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rootPanelLayout.createSequentialGroup()
                                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(28, 28, 28)
                                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2)
                                    .addGroup(rootPanelLayout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addComponent(jLabel3)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1287, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22))))
        );
        rootPanelLayout.setVerticalGroup(
            rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rootPanelLayout.createSequentialGroup()
                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(rootPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(buttonsFilePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panelButtonCompilerExecute, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(rootPanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel3)))
                .addGap(9, 9, 9)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(rootPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        getContentPane().add(rootPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        if (directorio.Open()) {
            colorAnalysis();
            clearFields();
        }
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if (directorio.Save()) {
            clearFields();              //to clean txt area 
            //jtpOp.setText(null);
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnGuardarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarCActionPerformed
        if (directorio.SaveAs()) {
            clearFields();              //to clean txt area
        }
    }//GEN-LAST:event_btnGuardarCActionPerformed

    private void btnCompilarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompilarActionPerformed
        if (getTitle().contains("*") || getTitle().equals(title)) {
            if (directorio.Save()) {
                compile();
            }
        } else {
            compile();
        }
    }//GEN-LAST:event_btnCompilarActionPerformed

    private void btnEjecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEjecutarActionPerformed
        btnCompilar.doClick();
        if (codeHasBeenCompiled) {
            if (!errors.isEmpty()) {
                JOptionPane.showMessageDialog(null, "EXISTEN ERRORES",
                        "EXISTEN ERRORES: EL CODIGO NO SE EJECUTO", JOptionPane.ERROR_MESSAGE);
            } else {
                //DIVIDIR CODIGO EN BLOQUES -> RECIBE TOKENS / BLOQUE INICIADOR DE CODIGO / BLOQUE TERMINADOR DE CODIGO / TERMINADOR DE SENTENCIA
                CodeBlock codeBlock = Functions.splitCodeInCodeBlocks(tokens, "{", "}", ";");
                //System.out.println(codeBlock);
                ArrayList<String> blocksOfCode = codeBlock.getBlocksOfCodeInOrderOfExec();
                System.out.println(blocksOfCode);
                executeCode(blocksOfCode, 1);
                
                String cadena = "25";
                
                
                //jtpOp.setText(cadena);
            }
        }
    }//GEN-LAST:event_btnEjecutarActionPerformed

    private void compile() {
        clearFields();
        lexicalAnalysis();              //to execute lexical analysis
        fillTableTokens();              //to fill tokens table
        syntacticAnalysis();            //to do syntactic analysis
        semanticAnalysis();             //to do semantic analysis
        printConsole();                 //to print in console
        codeHasBeenCompiled = true;
    }

    private void lexicalAnalysis() {
        // Extraer tokens
        Lexer lexer;
        try {
            File codigo = new File("code.encrypter");
            FileOutputStream output = new FileOutputStream(codigo);
            byte[] bytesText = jtpCode.getText().getBytes();
            output.write(bytesText);
            BufferedReader entrada = new BufferedReader(new InputStreamReader(new FileInputStream(codigo), "UTF8"));    //reconoce acentos o caracter extrano UTF8
            lexer = new Lexer(entrada);

            //add tokens 
            while (true) {
                Token token = lexer.yylex();        //return tokens
                if (token == null) {
                    break;
                }
                tokens.add(token);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Archivo no encontrado" + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("No se puede escribir en el archivo" + ex.getMessage());
        }
    }

    private void syntacticAnalysis() {
        Grammar gramatica = new Grammar(tokens, errors);        //

        /* Mostrar gramáticas */
        //PRODUCTIONS WILL BE REDUCE WHILE MORE TOKENS EXISTS IN A LINE OF CODE         MORE INSTRUCTIONS LESS PRODUCTIONS          TOKEN COMBINATION
        //SHOW ME THAT I NEED TO DELETE ERRORS
        gramatica.delete(new String[]{"ERROR_CERO_INICIAL", "ERROR_SIN_TIPO_DE_IDENTIFICADOR", "ERROR_SIMBOLO_INEXISTENTE"}, 1);    //error number = 1

        //COMBINACIONES
        //AGRUPACIONES DE OPERACIONES
        gramatica.group("OPERACION", "(TIPO_DE_DATO IDENTIFICADOR OPERADOR_DE_ASIGNACION IDENTIFICADOR OPERADOR_ARITMETICO IDENTIFICADOR PUNTO_Y_COMA)", true);
        
        
        
        
        
        
             
   
        //AGRUPACION DE VALORES
        gramatica.group("VALOR", "(NUMERO | COLOR)", true);         //this will stop in the first appearance

        //var statement     IR AGREGANDO LA VARIABLE AL ARRAYLIST   automaticamente se ira guardando en el arrayList identProd
        gramatica.group("VARIABLE", "TIPO_DE_DATO IDENTIFICADOR OPERADOR_DE_ASIGNACION VALOR", true, identProd);

        //COMBINACIONES CON ERRORES
        //error variable sin identificador
        gramatica.group("VARIABLE", "TIPO_DE_DATO OPERADOR_DE_ASIGNACION VALOR", true, 2,
                "ERROR SINTACTICO {}: Variable sin identificador [#, %]");

        gramatica.finalLineColumn();
        //error variable sin valor       prueba compi 4  
        gramatica.group("VARIABLE", "TIPO_DE_DATO IDENTIFICADOR OPERADOR_DE_ASIGNACION", 3,
                "ERROR SINTACTICO {}: Declaracion sin valor [#, %]");

        gramatica.initialLineColumn();

        //ERRORES DE DECLARACION        prueba compi4
        gramatica.delete("TIPO_DE_DATO", 4, "ERROR SINTACTICO{}: El tipo de dato no esta en una declaracion [#, %]");
        gramatica.delete("OPERADOR_DE_ASIGNACION", 5, "ERROR SINTACTICO {}: El operador de asignacion no esta en una declaracion [#, %]");

        //prueba compi 5       
        //AGRUPACION DE IDENTIFICADORES COMO UN VALOR Y DEFINICION DE PARAMETROS
        gramatica.group("VALOR", "IDENTIFICADOR", true);                    //expresion regular solo se cumple una vez con true

        //PARAMETRO SOLO UNO dentro de la funcion
        gramatica.group("PARAMETROS", "VALOR (COMA VALOR)+");

        //AGRUPACION DE FUNCIONES
        gramatica.group("FUNCION", "(INSTRUCCION_LEER | INSTRUCCION_ESCRIBIR | INSTRUCCION_ASIGNAR | CASE | BREAK | RETURN)", true);

        //AGRUPACION DE FUNCIONES CON PARAMETRO OPCIONAL o VALOR 
        gramatica.group("FUNCION_COMPLETA", "FUNCION PARENTESIS_DE_APERTURA (VALOR | PARAMETROS)? PARENTESIS_DE_CIERRE", true);

        //ERROR AGRUPACIONES SIN PARENTESIS DE APERTURA Y CIERRE
        gramatica.group("FUNCION_COMPLETA", "FUNCION (VALOR | PARAMETROS)? PARENTESIS_DE_CIERRE", true, 6,
                "ERROR SINTACTICO: Falta el parentesis de apertura [#. %]");

        gramatica.finalLineColumn();
        gramatica.group("FUNCION_COMPLETA", "FUNCION PARENTESIS_DE_APERTURA (VALOR | PARAMETROS)", true, 7,
                "ERROR SINTACTICO: Falta el parentesis de cierre [#. %]");
        gramatica.initialLineColumn();

        //ELIMINACION DE FUNCIONES INCOMPLETAS
        gramatica.delete("FUNCION", 8, "ERROR SINTACTICO {}: FUNCION DECLARADA INCORRECTAMENTE [#, %]");

        //EXPRESION LOGICA CON FUNCIONES MULTIPLES EN UNA SOLA PRODUCCION   & |   
        //gramatica.group("EXPRESION_LOGICA", "(FUNCION_COMPLETA) (OPERADOR_LOGICO FUNCION_COMPLETA)+");
        //loopForFunExecUntilChangeNotDetected DETECTA LAS AGRUPACIONES Y SE DETENDRA HASTA QUE NO QUEDE NINGUNA
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {

            gramatica.group("EXPRESION_LOGICA", "(FUNCION_COMPLETA | EXPRESION_LOGICA) (OPERADOR_LOGICO (FUNCION_COMPLETA | EXPRESION_LOGICA))+");

            // (EXPRESION)
            gramatica.group("EXPRESION_LOGICA", "PARENTESIS_DE_APERTURA (EXPRESION_LOGICA | FUNCION_COMPLETA) PARENTESIS_DE_CIERRE");
            //gramatica.group("EXPRESION_LOGICA", "(FUNCION_COMPLETA | EXPRESION_LOGICA) (OPERADOR_LOGICO (FUNCION_COMPLETA | EXPRESION_LOGICA))+");

        });

        //ELIMINACION DE OPERADORES LOGICOS
        gramatica.delete("OPERADOR_LOGICO", 10, "ERROR SINTACTICO {}: El operador logico no esta en la expresion");

        //agrupacion de expresiones logicas como valor y parametros
        gramatica.group("VALOR", "EXPRESION_LOGICA");               //un valor puede ser una expresion logica
        gramatica.group("PARAMETROS", "VALOR (COMA VALOR)+");       //lo que un parametro es

        //AGRUPACION DE ESTRUCTURAS DE CONTROL          WHILE   if
        gramatica.group("ESTRUCTURA_DE_CONTROL", "CICLO_WHILE | ESTRUCTURA_IF | CICLO_FOR | CONDICIONAL_SWITCH | METODO_VOID | RETORNO");
        gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA", "ESTRUCTURA_DE_CONTROL PARENTESIS_DE_APERTURA PARENTESIS_DE_CIERRE");

        //SWITCH
        gramatica.group("ESTRUCTURA_SWITCH", "CONDICIONAL_SWITCH PARENTESIS_DE_APERTURA IDENTIFICADOR PARENTESIS_DE_CIERRE LLAVE_DE_APERTURA CASE NUMERO FUNCION BREAK PUNTO_Y_COMA LLAVE_DE_CIERRE");
        
        
        
        
        
        
        
        
        
        
        
        //en caso de recibir un parametro
        gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA", "ESTRUCTURA_DE_CONTROL (VALOR | PARAMETROS)");
        gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA", "ESTRUCTURA_DE_CONTROL PARENTESIS_DE_APERTURA (VALOR | PARAMETROS) PARENTESIS_DE_CIERRE");

        //ELIMINACION DE ESTRUCTURAS DE CONTROL INCOMPLETAS
        gramatica.delete("ESTRUCTURA_DE_CONTROL", 11, "ERROR SINTACTICO {}: Estructura de control declarada de forma incorrecta [#, %]");

        //ELIMINACION DE PARENTESIS QUE SON INNECESARIOS
        gramatica.delete(new String[]{"PARENTESIS_DE_APERTURA", "PARENTESIS_DE_CIERRE"}, 12, "ERROR SINTACTICO {}: El parentesis [] no esta en una agrupacion [#, %]");

        //si falta ; PUNTO Y COMA
        gramatica.finalLineColumn();
        gramatica.group("VARIABLE_PC", "VARIABLE PUNTO_Y_COMA", true);
        gramatica.group("VARIABLE_PC", "VARIABLE", true, 13, "ERROR SINTACTICO {}: No se hallo ; al final de la variable [#, %]");

        //FUNCIONES
        gramatica.group("FUNCION_COMPLETA_PC", "FUNCION_COMPLETA PUNTO_Y_COMA");
        gramatica.group("FUNCION_COMPLETA_PC", "FUNCION_COMPLETA", 14, "ERROR SINTACTICO {}: No se hallo ; al final de la funcion [#, %]");

        gramatica.initialLineColumn();

        //SENTENCIA = DECLARACION DE VARIABLE O FUNCION + punto y coma
        //ELIMINACION DEL PUNTO Y COMA
        gramatica.delete("PUNTO_Y_COMA", 15, "ERROR SINTACTICO {}: No se hallo ; al final de la sentencia [#, %]");

        //SENTENCIAS
        gramatica.group("SENTENCIAS", "(VARIABLE_PC | FUNCION_COMPLETA_PC)+");

        //VOID
        gramatica.group("FUNCION_VOID", "METODO_VOID ESTRUCTURA_DE_CONTROL_COMPLETA");
        
        //RETORNO
        gramatica.group("FUNCION_RETORNO", "ESTRUCTURA_DE_CONTROL_COMPLETA RETORNO");
        
        
        
        
        
        
        
        
        
        
        
        
        
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA_LASLC", "ESTRUCTURA_DE_CONTROL_COMPLETA LLAVE_DE_APERTURA (SENTENCIAS)? LLAVE_DE_CIERRE", true);
            gramatica.group("SENTENCIAS", "(SENTENCIAS | ESTRUCTURA_DE_CONTROL_COMPLETA_LASLC)+");
        });

        //ESTRUCTURAS DE FUNCION INCOMPLETAS
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            gramatica.initialLineColumn();

            gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA_LASLC", "ESTRUCTURA_DE_CONTROL_COMPLETA (SENTENCIAS)? LLAVE_DE_CIERRE", true,
                    15, "ERROR SINTACTICO {}: Falta llave de apertura en la estructura de control");
            gramatica.finalLineColumn();

            gramatica.group("ESTRUCTURA_DE_CONTROL_COMPLETA_LASLC", "ESTRUCTURA_DE_CONTROL_COMPLETA LLAVE_DE_APERTURA SENTENCIAS", true,
                    15, "ERROR SINTACTICO {}: Falta llave de cierre en la estructura de control");

            gramatica.group("SENTENCIAS", "(SENTENCIAS | ESTRUCTURA_DE_CONTROL_COMPLETA_LASLC)");
        });

        //ELIMINAMOS LLAVE DE APERTURA Y CIERRE
        gramatica.delete(new String[]{"LLAVE_DE_APERTURA", "LLAVE_DE_CIERRE"}, 16, "ERROR SINTACTICO {}: La llave [] no esta en una agrupacion [#, %]");

        gramatica.show();
    }

    private void semanticAnalysis() {
        //FOR PARA RECORRER CADA UNO DE LOS IDENTIFICADORES
        //HASHmap para asociar un tipo de dato con un valor
        HashMap<String, String> identDataType = new HashMap<>();
        identDataType.put("color", "COLOR");
        identDataType.put("numero", "NUMERO");

        for (Production id : identProd) {
            if (!identDataType.get(id.lexemeRank(0)).equals(id.lexicalCompRank(-1))) {      //retorna el tipo que es
                errors.add(new ErrorLSSL(1, "ERROR SEMANTICO {}: El valor no es compatible con el tipo de dato [#, %]", id, true));
            } else if (id.lexicalCompRank(-1).equals("COLOR") && !id.lexemeRank(-1).matches("#[0-9a-fA-F]+")) {
                errors.add(new ErrorLSSL(2, "ERROR SEMANTICO {}: El color no es un numero hexadecimal [#, %]", id, false));
            } else {  //si no  hay errores el identificador se guarda en el hashMap de identificadores
                identificadores.put(id.lexemeRank(1), id.lexemeRank(-1));
            }

            /*
            System.out.println(id.lexemeRank(0, -1));           //imprime el lexema
            System.out.println(id.lexicalCompRank(0, -1));      //imprime el componente lexico
             */
        }
    }

    private void colorAnalysis() {
        /* Limpiar el arreglo de colores */
        textsColor.clear();
        /* Extraer rangos de colores */
        LexerColor lexerColor;
        try {
            File codigo = new File("color.encrypter");
            FileOutputStream output = new FileOutputStream(codigo);
            byte[] bytesText = jtpCode.getText().getBytes();
            output.write(bytesText);
            BufferedReader entrada = new BufferedReader(new InputStreamReader(new FileInputStream(codigo), "UTF8"));
            lexerColor = new LexerColor(entrada);
            while (true) {
                TextColor textColor = lexerColor.yylex();
                if (textColor == null) {
                    break;
                }
                textsColor.add(textColor);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("ARCHIVO NO ENCONTRADO" + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("NO SE PUDO EDITAR EL ARCHIVO" + ex.getMessage());
        }
        Functions.colorTextPane(textsColor, jtpCode, new Color(40, 40, 40));            //40, 40, 40 black
    }

    private void fillTableTokens() {
        tokens.forEach(token -> {
            Object[] data = new Object[]{token.getLexicalComp(), token.getLexeme(), "[" + token.getLine() + ", " + token.getColumn() + "]"};
            Functions.addRowDataInTable(tblTokens, data);
        });
    }

    private void printConsole() {
        int sizeErrors = errors.size();
        if (sizeErrors > 0) {
            Functions.sortErrorsByLineAndColumn(errors);            //ordena errores por numero de linea y columna          
            String strErrors = "\n";
            for (ErrorLSSL error : errors) {                            //recorre cada error
                String strError = String.valueOf(error);
                strErrors += strError + "\n";
            }
            jtaOutputConsole.setText("ERROR DE ANALISIS: \n" + strErrors);
        } else {
            jtaOutputConsole.setText("Analisis realizado correctamente");
        }
        jtaOutputConsole.setCaretPosition(0);
    }

    private void clearFields() {
        Functions.clearDataInTable(tblTokens);          //to clear data in tokens
        jtaOutputConsole.setText("");
        tokens.clear();
        errors.clear();
        identProd.clear();
        identificadores.clear();
        codeHasBeenCompiled = false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatIntelliJLaf());            //
            } catch (UnsupportedLookAndFeelException ex) {
                System.out.println("LookAndFeel no soportado: " + ex);
            }
            new Compilador().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnCompilar;
    private javax.swing.JButton btnEjecutar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnGuardarC;
    private javax.swing.JPanel buttonsFilePanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jtaOutputConsole;
    private javax.swing.JTextPane jtpCode;
    private javax.swing.JPanel panelButtonCompilerExecute;
    private javax.swing.JPanel rootPanel;
    private javax.swing.JTable tblTokens;
    // End of variables declaration//GEN-END:variables
}
