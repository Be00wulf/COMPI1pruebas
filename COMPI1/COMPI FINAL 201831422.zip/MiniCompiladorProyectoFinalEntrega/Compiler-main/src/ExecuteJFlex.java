
import jflex.exceptions.SilentExit;

/**
 *
 * @author majo
 */
public class ExecuteJFlex {

    public static void main(String omega[]) {
        String lexerFile = System.getProperty("user.dir") + "/src/Lexer.flex", //keep color 
                lexerFileColor = System.getProperty("user.dir") + "/src/LexerColor.flex";
        try {
            jflex.Main.generate(new String[]{lexerFile, lexerFileColor});
        } catch (SilentExit ex) {
            System.out.println("ERROR: archivo Flex" + ex);
        }
    }
}
